<!DOCTYPE html>
<?php
$name = $_POST['name'];
$position = $_POST['position'];
$password = $_POST['password'];
$confirm = $_POST['confirm'];
$errors = [];

if (empty($name)){
     $errors[]="input nama belum diisi";
}
if (empty($password)){
     $errors[]="input password belum diisi";
}
if (empty($confirm)){
    $confirm[]="input confirm password belum diisi";
}
if ($password !== $confirm) {
  $errors[] = "password dan confirm belum sama";
}
if (!empty($errors)) {
  echo "<div style='color:red'>";
  foreach ($errors as $e) {
    echo $e . "<br>";
  }
  echo "<a href='index.php'>kembali ke halaman awal</a>";
  echo "</div>";
}
?>
</html>