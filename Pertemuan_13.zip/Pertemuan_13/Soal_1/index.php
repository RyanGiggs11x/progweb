<!DOCTYPE html>
<html>
<head>
  <title>Add profile</title>
</head>
<body>
  <form action="proses.php" method="post">
    <table border="1">
      <tr>
        <th colspan="2">Add profile</th>
      </tr>
      <tr>
        <td>Name</td>
        <td><input type="text" name="name"></td>
      </tr>
      <tr>
        <td>Position</td>
        <td>
          <select name="position">
            <option>Senior Programmer</option>
            <option>Programmer</option>
            <option>Junior Programmer</option>
            <option>System Analyst</option>
            <option>Senior Analyst</option>
            <option>Junior Analyst</option>
            </select>
        </td>
      </tr>
      <tr>
        <td>Password</td>
        <td><input type="password" name="password"></td>
      </tr>
      <tr>
        <td>Confirm Password</td>
        <td><input type="password" name="confirm"></td>
      </tr>
      <tr>
        <td colspan="2" align="center">
          <input type="reset" value="Reset">
          <input type="submit" value="Save">
        </td>
      </tr>
    </table>
  </form>
</body>
</html>
