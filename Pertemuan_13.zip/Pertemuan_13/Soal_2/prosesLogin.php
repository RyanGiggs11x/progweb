<!DOCTYPE html>
<?php    
    $username = $_POST['username']; 
    $password = $_POST['password'];
    if ($username == "admin" && $password == "admin") {
    echo "<h2>Login berhasil!</h2>"; 
    echo "<h3>Selamat datang, <span style='color: blue;'>admin</span>.</h3>";
    echo "<a href='index.html'>kembali ke halaman login</a>";
    } else {
    echo "<p><b><span style = 'color: red;'>Username</span> : $username
    <span style ='color: red;'>Tidak Terdaftar!</span></b></p>";
    echo "<a href='index.html'>kembali ke halaman login</a>";
}
?>
</html>
